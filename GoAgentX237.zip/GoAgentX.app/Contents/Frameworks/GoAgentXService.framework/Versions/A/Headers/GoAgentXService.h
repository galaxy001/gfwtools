//
//  GoAgentXService.h
//  GoAgentXService
//
//  Created by Xu Jiwei on 13-5-14.
//  Copyright (c) 2013年 GoAgentX.com. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "GAService.h"
#import "GAServiceProfile.h"

@interface GoAgentXService : NSObject

@end
